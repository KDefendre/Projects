 import java.net.*;

import java.io.*;

import java.util.*;

public class TCPClient {

private static final int PORT = 5000;

private static final String HOSTNAME = "localhost";

public static void main(String[] args) {

Scanner scanner = new Scanner(System.in);

while(true)

{

try {

Socket socket = null;

try {

socket = new Socket(HOSTNAME, PORT);

} catch (UnknownHostException e) {

e.printStackTrace();

}

System.out.println("Connected.");

DataOutputStream out = new DataOutputStream(socket.getOutputStream());

DataInputStream in = new DataInputStream(socket.getInputStream());

 

System.out.println("Enter input: ");

String line = scanner.nextLine();

if(line.equalsIgnoreCase("quit"))

{

System.out.println("Bye!");

break;

}

out.writeUTF(line);

out.flush();

String response = in.readUTF();

System.out.println(response);

out.close();

in.close();

socket.close();

} catch(IOException e) {

e.printStackTrace();

}

}

}

}