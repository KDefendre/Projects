 
 import java.net.*;

import java.io.*;

public class TCPStringServerPersistentMultithread {

    private static int PORT = 5000; 
    public static Socket connectionSocket;
    public static DataInputStream in;
    public static DataOutputStream out;
    	

    public static void main(String[] args) {

        try {

            ServerSocket server = new ServerSocket(PORT);

            System.out.println("This is the TCP Server.");
  


                System.out.println("Client accepted.");
                 
            while (true) {
            	connectionSocket = server.accept();
            	in = new DataInputStream(connectionSocket.getInputStream());
                out = new DataOutputStream(connectionSocket.getOutputStream());

                Runnable thread = new Thread(new Multithread(connectionSocket, in, out));
                ((Thread) thread).start();
				}
				
                 
                 
                
                
               

                // in order serve multiple request connection should not be closed

            }

         catch (IOException e) {

            e.printStackTrace();

         }

    }
}



class Multithread implements Runnable{
	 Socket sock;
	 DataInputStream in;
	 DataOutputStream out;
	 public  Multithread ( Socket sock,  DataInputStream in, DataOutputStream out){
		this.sock = sock;
		this.in = in;
		this.out = out;
	}
	
	public void run(){
		 try{
			 while (true) {
					String line = in.readUTF();
					if (line.equalsIgnoreCase("Quit")) {
						sock.close();
						in.close();
						out.close();
						break;
					} else {
						String newLine = line.toUpperCase();
						out.writeUTF(newLine);
						out.flush();
					} 
				}  
		 }catch(IOException e){
			 e.printStackTrace();
		 }
	}		 
}

     
