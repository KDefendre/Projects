
 import java.net.*;

import java.io.*;

public class TCPStringServerPersistent {

    private static int PORT = 5000;

    public static void main(String[] args) {

        try {

            ServerSocket server = new ServerSocket(PORT);

            System.out.println("This is the TCP Server.");
  


                System.out.println("Client accepted.");
                 
            while (true) {
            	Socket connectionSocket = server.accept();
             

DataInputStream in = new DataInputStream(connectionSocket.getInputStream());

                DataOutputStream out = new DataOutputStream(connectionSocket.getOutputStream());

                while (true) {
					String line = in.readUTF();
					if (line.equalsIgnoreCase("Quit")) {
						connectionSocket.close();
						in.close();
						out.close();
						break;
					} else {
						String newLine = line.toUpperCase();
						out.writeUTF(newLine);
						out.flush();
					} 
				}
				System.out.println("Closing connection.");
                 
                 
                
                
               

                // in order serve multiple request connection should not be closed

            }

        } catch (IOException e) {

            e.printStackTrace();

        }

    }

}