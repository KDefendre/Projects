
import java.net.*;

import java.io.*;

import java.util.*;

public class TCPStringClientPersistent {

private static final int PORT = 5000;

private static final String HOSTNAME = "localhost";

public static void main(String[] args) {

Scanner scanner = new Scanner(System.in);

 
	try {

		Socket socket = null;

			try {

				socket = new Socket(HOSTNAME, PORT);

			} 
			
			catch (UnknownHostException e) {

				e.printStackTrace();
			}



			System.out.println("Connected.");

			DataOutputStream out = new DataOutputStream(socket.getOutputStream());

			DataInputStream in = new DataInputStream(socket.getInputStream());
			String output;
			while(true){
	 
				String line = scanner.nextLine();
				out.writeUTF(line);
				out.flush();
				if(line.equalsIgnoreCase("quit")){

					System.out.println("Bye!");

					break;
	 
				}
				else{
					output = in.readUTF();
					System.out.println(output);
				}
				

 


			}
			scanner.close();
			out.close();
			in.close();
			socket.close();
	}










 




catch(IOException e) {

e.printStackTrace();
}
			}
	}


	



