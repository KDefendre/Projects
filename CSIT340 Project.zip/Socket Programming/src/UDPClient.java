 import java.io.*;

import java.net.*;

import java.util.Scanner;

public class UDPClient {

private final static int PORT = 5000;

private static final String HOSTNAME = "localhost";

public static void main(String[] args) {

System.out.println("This is the UDP Client.");

try {

Scanner scanner = new Scanner(System.in);

while(true)

{

DatagramSocket socket = new DatagramSocket(0);

System.out.println("Put genter input: ");

String requestString = scanner.next();

if(requestString.equalsIgnoreCase("quit"))

{

System.out.println("Bye!");

break;

}

byte[] requestBuffer = requestString.getBytes();

InetAddress host = InetAddress.getByName(HOSTNAME);

DatagramPacket request = new DatagramPacket(requestBuffer, requestBuffer.length, host,

PORT);

socket.send(request);

DatagramPacket response = new DatagramPacket(new byte[1024], 1024);

socket.receive(response);

String result = new String(response.getData());

//CSIT 340 Computer Networks

System.out.println(result);

}

} catch (IOException e) {

e.printStackTrace();

}

}

}