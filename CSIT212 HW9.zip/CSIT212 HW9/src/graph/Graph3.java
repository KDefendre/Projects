 package graph;

import java.util.Comparator;
import java.util.PriorityQueue;

public class Graph3 {
	int n;
	int[][] A;
	int[] d;	//shortest distance
	/**
	 * @param args
	 */
	
	public Graph3 () {
		
	}
	
	public Graph3 (int _n, int[][] _A) {
		n = _n;
		A = _A;
		d = new int[n];
	}
	
	public void initialize_single_source(int s) {
		for (int i = 0; i < n; i++)
			d[i] = Integer.MAX_VALUE;
		d[s] = 0;
	}
	
	public void relax (int u, int v) {
		if (d[v] > (d[u] + A[u][v])) 
			d[v] = d[u] + A[u][v];
	}
	
	public boolean bellman_ford (int s) {
		//fill in your program
		initialize_single_source(d[s]);
		for(int i = 1;i<d[i];i++){
			for(int j = 0;j<n;j++){
			relax(d[i],d[j]);
			}
		}
		int j = 0;
		for(int i = 0; i<n-1; i++){
			if(d[i]<d[j]){
				return false;
			}
		}
		for(int i = 0; i<n;i++){
			for(int k = 0; k<n; k++){
				if(A[i][k] != 0){
					if(d[i]>d[k]+A[i][k]){
						return false;
					}
				}
			}
		}
		return true;
	}
	public static Comparator<Node> idComparator = new Comparator<Node>(){
		
		
		public int compare(Node c1, Node c2) {
            return (int) (c1.getValue() - c2.getValue());
        }
	};
	
		public void dijkstra (int s) {
		//fill in your program
		  
		initialize_single_source(s);
		s = 0;
		int v;
		Node u;
		boolean[] prev;
		PriorityQueue<Node> P = new PriorityQueue<Node>(idComparator);
		 for(int i = 1;i<n;i++){
			
			if(n!= 0){
				 d[v] = Integer.MAX_VALUE;
				 prev[v] = false;
				 P.add(new Node(d[v],null));
			 }
			 while(!P.isEmpty()){
				 u =  P.poll();
				 for(int j = 0;j<n[i];j++){
					int  key = d[u] + length(u,v);
					if(key<d[v]){
						d[v] = key;
						prev[v] = u;
						P.subtract(v,key);
					}
					return true;
				 }
			 }
		 }
		} 
	
	
	public void display_distance () {
		for (int i = 0; i < n; i++)
			System.out.println(i + ": " + d[i]);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 5;
		int[][] A = {
		{0, 6, 0, 7, 0},
		{0, 0, 5, 8, -4},
		{0, -2, 0, 0, 0},
		{0, 0, -3, 0, 9},
		{2, 0, 7, 0, 0}
		};
		Graph3 g1 = new Graph3(n, A);
		g1.bellman_ford(0);
		g1.display_distance();
		
		System.out.println("-----------------------");
		
		int[][] B = {
		{0, 10, 0, 5, 0},
		{0, 0, 1, 2, 0},
		{0, 0, 0, 0, 4},
		{0, 3, 9, 0, 2},
		{7, 0, 6, 0, 0}
		};
		Graph3 g2 = new Graph3(n, B);
		g2.dijkstra(0);
		g2.display_distance();
	}


}


