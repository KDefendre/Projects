package graph;

import java.util.Queue;
import java.util.LinkedList;
import java.util.ArrayList;

public class Graph {
	public int n;	//number of vertice
	public int[][] A;	//the adjacency matrix
	private final int WHITE = 2;
	private final int GRAY = 3;
	private final int BLACK = 4;
	
	public Graph () {
		n = 0;
		A = null;
	}
	
	public Graph (int _n, int[][] _A) {
		this.n = _n;
		this.A = _A;
	}
	
	/*
	 * Input: s denotes the index of the source node
	 * Output: the array dist, where dist[i] is the distance between the i-th node to s
	 */
	public int[] bfs (int s) {
		int[] N= new int [n];
		int[]parent = new int [n];
		int dist[] = new int [n];
		for(int i = 0; i<n; i++){
			N[i] = WHITE;
			parent[i] = 0;
			dist[i] = 0;
		}
		Queue <Integer> myNumbers = new LinkedList<>();
		myNumbers.add(s);
		myNumbers.isEmpty();
		while(!myNumbers.isEmpty()){
			int u = myNumbers.peek();
			myNumbers.remove(u);
			ArrayList<Integer> list = new ArrayList<Integer>();
			int j = 0;
			for(j = 0; j<n; j++){
				 if(A[s][j] == 1){
					 list.add(j);
				 }
				 for(int k = 0; k<list.size(); k++){
					 if(N[k] == 2){
						 N[k] = GRAY;
						 dist[k] = dist[j] + 1;
						 myNumbers.add(N[k]);
					 }
					 N[u] = BLACK;
				 }
				
			}
		}
		 return dist;
	}

	 
	public void print_array (int[] array) {
		for (int i = 0; i < array.length; i++)
			System.out.println(i + ": " + array[i]);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 8;
		int[][] A = 
			{{0, 1, 0, 0, 1, 0, 0, 0},
			{1, 0, 0, 0, 0, 1, 0, 0},
			{0, 0, 0, 1, 0, 1, 1, 0},
			{0, 0, 1, 0, 0, 0, 1, 1},
			{1, 0, 0, 0, 0, 0, 0, 0},
			{0, 1, 1, 0, 0, 0, 1, 0},
			{0, 0, 1, 1, 0, 1, 0, 1},
			{0, 0, 0, 1, 0, 0, 1, 0}};
		Graph g = new Graph(n, A);
		g.print_array(g.bfs(1));
	}

}

