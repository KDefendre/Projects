package graph;

public class Graph2 {
	
	public int n;	//number of vertice
	public int[][] A;	//the adjacency matrix
	
	public Graph2 () {
		n = 0;
		A = null;
	}
	
	public Graph2 (int _n, int[][] _A) {
		this.n = _n;
		this.A = _A;
	}
	int minKey(int key[], Boolean graph2[])
    {
        
        int min = Integer.MAX_VALUE, min_index=-1;
 
        for (int i = 0; i < n; i++)
            if (graph2[i] == false && key[i] < min)
            {
                min = key[i];
                min_index = i;
            }
 
        return min_index;
    }
	public int prim (int r) {
		int key[] = new int [n];
		int []parent = new int [n];
		for(int i = 0; i<n; i++){
			key[i] = Integer.MAX_VALUE;
		}
		Boolean graph2[] = new Boolean[n];
		for(int i = 0;i<n;i++){
			 graph2[i] = false;
		}
		r = 0;
		key[r] = 0;
		parent[r] = -1;
		for(int i = 0; i<n-1; i++){
			int m =  minKey(key,graph2);
			graph2[m] = true;
			for(int j = 0; j<n; j++){
				if(A[m][j] != 0 && graph2[j] == false && A[m][j] < key[j]){
					parent[j] = m;
					key[j] = A[m][j];
				}
			}
		}
		 int result = 0;
		 for(int i = 0; i<n; i++){
			 result += key[i];
		 }
		 return result;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 9;
		int A[][] = {
				{0, 4, 0, 0, 0, 0, 0, 8, 0}, 
				{4, 0, 8, 0, 0, 0, 0, 11, 0}, 
				{0, 8, 0, 7, 0, 4, 0, 0, 2}, 
				{0, 0, 7, 0, 9, 14, 0, 0, 0}, 
				{0, 0, 0, 9, 0, 10, 0, 0, 0}, 
				{0, 0, 4, 14, 10, 0, 2, 0, 0}, 
				{0, 0, 0, 0, 0, 2, 0, 1, 6}, 
				{8, 11, 0, 0, 0, 0, 1, 0, 7}, 
				{0, 0, 2, 0, 0, 0, 6, 7, 0} 
		};
		Graph2 g = new Graph2(n, A);
		System.out.println(g.prim(0));
	}

}

